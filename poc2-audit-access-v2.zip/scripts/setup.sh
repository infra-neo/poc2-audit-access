#!/usr/bin/env bash
docker compose up -d

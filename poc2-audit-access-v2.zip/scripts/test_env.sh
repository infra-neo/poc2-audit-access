curl -I http://localhost:9000 || true
curl -I http://localhost:6901 || true
